# 🥞 Fastswap Frontend

This project contains the main features of the fastswap application.

If you want to contribute, please refer to the [contributing guidelines](./CONTRIBUTING.md) of this project.
