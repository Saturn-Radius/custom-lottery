export type DividerFill = {
  light: string
  dark?: string
}

export type ClipFill = {
  light: string
  dark?: string
}
