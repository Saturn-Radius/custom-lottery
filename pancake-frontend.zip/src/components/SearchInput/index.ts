export { default } from './SearchInput'
